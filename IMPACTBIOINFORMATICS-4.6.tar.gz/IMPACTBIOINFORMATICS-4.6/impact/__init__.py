from .impact import train, predict
